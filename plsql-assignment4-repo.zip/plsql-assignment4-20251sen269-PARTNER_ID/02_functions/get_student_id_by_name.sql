-- Looks a student up by full name (case-insensitive).
-- Demonstrates the predefined exceptions NO_DATA_FOUND and TOO_MANY_ROWS.
CREATE OR REPLACE FUNCTION get_student_id_by_name (
  p_full_name IN students.full_name%TYPE
) RETURN students.student_id%TYPE
IS
  l_student_id students.student_id%TYPE;
BEGIN
  SELECT student_id
    INTO l_student_id
    FROM students
   WHERE UPPER(full_name) = UPPER(TRIM(p_full_name));

  RETURN l_student_id;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20060, 'No student found with name "' || p_full_name || '".');
  WHEN TOO_MANY_ROWS THEN
    RAISE_APPLICATION_ERROR(-20061, 'More than one student is named "' || p_full_name || '". Use the student ID instead.');
END get_student_id_by_name;
/
SHOW ERRORS
