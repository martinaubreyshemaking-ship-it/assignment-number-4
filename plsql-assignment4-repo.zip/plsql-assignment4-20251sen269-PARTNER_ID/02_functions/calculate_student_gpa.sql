-- Credit-weighted GPA on a 4.0 scale (A=4, B=3, C=2, D=1, F=0) over graded enrollments only.
-- Returns NULL (not 0) when the student has no graded courses yet, because 0 would be misleading.
-- Raises -20080 if the student does not exist.
CREATE OR REPLACE FUNCTION calculate_student_gpa (
  p_student_id IN students.student_id%TYPE
) RETURN NUMBER
IS
  l_dummy PLS_INTEGER;
  l_gpa   NUMBER;
BEGIN
  SELECT 1 INTO l_dummy FROM students WHERE student_id = p_student_id;  -- NO_DATA_FOUND if missing

  SELECT ROUND(
           SUM(CASE e.letter_grade
                 WHEN 'A' THEN 4 WHEN 'B' THEN 3 WHEN 'C' THEN 2 WHEN 'D' THEN 1 ELSE 0
               END * c.credits) / SUM(c.credits), 2)
    INTO l_gpa
    FROM enrollments e
    JOIN courses c ON c.course_id = e.course_id
   WHERE e.student_id = p_student_id
     AND e.score IS NOT NULL;

  RETURN l_gpa;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20080, 'Student ' || p_student_id || ' does not exist.');
END calculate_student_gpa;
/
SHOW ERRORS
