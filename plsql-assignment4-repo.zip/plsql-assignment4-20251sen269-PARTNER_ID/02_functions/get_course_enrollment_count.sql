-- Returns how many students are enrolled in a course for a semester.
-- Raises -20070 if the course does not exist (so 0 is never a misleading answer).
CREATE OR REPLACE FUNCTION get_course_enrollment_count (
  p_course_id IN courses.course_id%TYPE,
  p_semester  IN enrollments.semester%TYPE
) RETURN NUMBER
IS
  l_exists PLS_INTEGER;
  l_count  NUMBER;
BEGIN
  SELECT 1 INTO l_exists FROM courses WHERE course_id = p_course_id;   -- NO_DATA_FOUND if missing

  SELECT COUNT(*) INTO l_count
    FROM enrollments
   WHERE course_id = p_course_id
     AND semester  = p_semester;

  RETURN l_count;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20070, 'Course ' || p_course_id || ' does not exist.');
END get_course_enrollment_count;
/
SHOW ERRORS
