-- Percentage of graded students with score >= 60 in a course/semester.
-- Uses BULK COLLECT into a nested table, then processes the collection.
-- Raises -20090 when nothing is graded yet (instead of returning a misleading 0).
CREATE OR REPLACE FUNCTION get_course_pass_rate (
  p_course_id IN courses.course_id%TYPE,
  p_semester  IN enrollments.semester%TYPE
) RETURN NUMBER
IS
  TYPE t_score_tab IS TABLE OF enrollments.score%TYPE;   -- nested table
  l_scores t_score_tab;
  l_passed PLS_INTEGER := 0;
BEGIN
  SELECT score
    BULK COLLECT INTO l_scores
    FROM enrollments
   WHERE course_id = p_course_id
     AND semester  = p_semester
     AND score IS NOT NULL;

  IF l_scores.COUNT = 0 THEN
    RAISE_APPLICATION_ERROR(-20090, 'No graded enrollments for ' || p_course_id || ' in ' || p_semester || '.');
  END IF;

  FOR i IN 1 .. l_scores.COUNT LOOP
    IF l_scores(i) >= 60 THEN
      l_passed := l_passed + 1;
    END IF;
  END LOOP;

  RETURN ROUND(l_passed / l_scores.COUNT * 100, 1);
END get_course_pass_rate;
/
SHOW ERRORS
