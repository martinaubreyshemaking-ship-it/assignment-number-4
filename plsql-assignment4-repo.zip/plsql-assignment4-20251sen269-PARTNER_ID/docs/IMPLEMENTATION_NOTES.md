# Implementation and Performance Notes

## Design choices
- **Letter grade is a virtual column** computed from `score`, so it can never disagree with the score and no code has to maintain it.
- **Procedures never COMMIT.** The caller owns the transaction, so several calls can be combined and rolled back together (the tests rely on this).
- **Functions never hide errors.** `calculate_student_gpa` returns NULL (not 0) when nothing is graded, and the other functions raise a clear `-20xxx` error instead of returning a fake value.
- **Unexpected errors are never swallowed.** Every `WHEN OTHERS` logs with `DBMS_OUTPUT` and re-raises with `RAISE`.
- **Capacity check is simple, not race-proof.** Two sessions could pass the seat check at the same moment. A production system would lock the course row (`SELECT ... FOR UPDATE`) first.

## Records and collections
- `%ROWTYPE` gives a whole table row in one variable (`students%ROWTYPE`, `courses%ROWTYPE`).
- User-defined records group just the columns we need (`t_transcript_rec`, `t_audit_rec`).
- Nested tables hold query results (`BULK COLLECT`), an associative array (`t_failed_map`) marks which FORALL iterations failed,
  and a VARRAY (`SYS.ODCINUMBERLIST`) is the input list of student IDs.

## Cursors
- **Implicit cursors:** `SQL%ROWCOUNT`, `SQL%FOUND`, `SQL%NOTFOUND` are read immediately after the DML statement, because the next DML overwrites them.
- **Explicit cursor:** `print_transcript` uses a parameterized cursor with OPEN / FETCH / CLOSE, and closes it in the exception handler if still open.

## Bulk processing and performance
PL/SQL and SQL run in separate engines. A row-by-row loop with an `UPDATE` inside switches between them once per row; with N rows that is N context switches.
`BULK COLLECT` fetches all rows in one switch and `FORALL` sends the whole collection to the SQL engine in one switch, which cuts that overhead.
The bigger the batch, the bigger the gain. For a handful of rows the difference is negligible; for thousands it is usually large.

Practical points:
- `FORALL` handles one DML statement only, and all rows are sent together.
- Without `SAVE EXCEPTIONS`, the first bad row stops the FORALL and the earlier rows are rolled back to the statement savepoint.
  With `SAVE EXCEPTIONS`, Oracle keeps going, then raises ORA-24381; `SQL%BULK_EXCEPTIONS(j).ERROR_INDEX` and `.ERROR_CODE` tell us which iteration failed and why.
- `bulk_adjust_scores` audits only the successful iterations, so the audit table matches what really changed.
- For very large result sets, use `BULK COLLECT ... LIMIT n` in a loop so the collection does not use too much PGA memory. Our class-sized data does not need it.

To measure the difference yourself, time a row-by-row loop against the FORALL version on the same data with `DBMS_UTILITY.GET_TIME` or `SET TIMING ON`
and record the numbers here: _(add your own measurements)_.
