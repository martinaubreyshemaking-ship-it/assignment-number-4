-- 01_create_tables.sql : Student Registration and Grading schema (Oracle 12c+)
-- Safe to re-run: drops the tables first.

BEGIN
  FOR t IN (SELECT column_value AS tname
              FROM TABLE(SYS.ODCIVARCHAR2LIST('GRADE_AUDIT','ENROLLMENTS','COURSES','STUDENTS'))) LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE ' || t.tname || ' CASCADE CONSTRAINTS PURGE';
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE != -942 THEN RAISE; END IF;  -- ignore "table does not exist" only
    END;
  END LOOP;
END;
/

CREATE TABLE students (
  student_id   NUMBER(6)     CONSTRAINT pk_students PRIMARY KEY,
  full_name    VARCHAR2(100) NOT NULL,
  email        VARCHAR2(120) NOT NULL CONSTRAINT uq_students_email UNIQUE,
  status       VARCHAR2(10)  DEFAULT 'ACTIVE' NOT NULL
               CONSTRAINT chk_students_status CHECK (status IN ('ACTIVE','SUSPENDED','GRADUATED')),
  enrolled_on  DATE          DEFAULT SYSDATE NOT NULL
);

CREATE TABLE courses (
  course_id  VARCHAR2(10)  CONSTRAINT pk_courses PRIMARY KEY,
  title      VARCHAR2(100) NOT NULL,
  credits    NUMBER(2)     NOT NULL CONSTRAINT chk_courses_credits CHECK (credits BETWEEN 1 AND 6),
  capacity   NUMBER(3)     DEFAULT 40 NOT NULL CONSTRAINT chk_courses_capacity CHECK (capacity > 0)
);

CREATE TABLE enrollments (
  enrollment_id NUMBER GENERATED ALWAYS AS IDENTITY CONSTRAINT pk_enrollments PRIMARY KEY,
  student_id    NUMBER(6)    NOT NULL CONSTRAINT fk_enr_student REFERENCES students(student_id),
  course_id     VARCHAR2(10) NOT NULL CONSTRAINT fk_enr_course  REFERENCES courses(course_id),
  semester      VARCHAR2(10) NOT NULL,
  score         NUMBER(5,2)  CONSTRAINT chk_enr_score CHECK (score BETWEEN 0 AND 100),
  -- letter grade is derived from score, so it can never be out of sync
  letter_grade  VARCHAR2(1) GENERATED ALWAYS AS (
                  CASE WHEN score IS NULL THEN NULL
                       WHEN score >= 90 THEN 'A'
                       WHEN score >= 80 THEN 'B'
                       WHEN score >= 70 THEN 'C'
                       WHEN score >= 60 THEN 'D'
                       ELSE 'F' END) VIRTUAL,
  CONSTRAINT uq_enrollment UNIQUE (student_id, course_id, semester)
);

CREATE TABLE grade_audit (
  audit_id      NUMBER GENERATED ALWAYS AS IDENTITY CONSTRAINT pk_grade_audit PRIMARY KEY,
  enrollment_id NUMBER NOT NULL
                CONSTRAINT fk_audit_enr REFERENCES enrollments(enrollment_id) ON DELETE CASCADE,
  old_score     NUMBER(5,2),
  new_score     NUMBER(5,2),
  changed_on    DATE         DEFAULT SYSDATE NOT NULL,
  changed_by    VARCHAR2(30) DEFAULT USER NOT NULL
);

CREATE INDEX idx_enr_course_sem ON enrollments(course_id, semester);
