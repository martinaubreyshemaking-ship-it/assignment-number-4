-- 02_insert_sample_data.sql

INSERT INTO students (student_id, full_name, email, status) VALUES (1001, 'Aline Uwimana',      'aline.uwimana@example.com',   'ACTIVE');
INSERT INTO students (student_id, full_name, email, status) VALUES (1002, 'Eric Habimana',      'eric.habimana@example.com',   'ACTIVE');
INSERT INTO students (student_id, full_name, email, status) VALUES (1003, 'Grace Mukamana',     'grace.mukamana@example.com',  'ACTIVE');
INSERT INTO students (student_id, full_name, email, status) VALUES (1004, 'Jean Claude Uwase',  'jc.uwase1@example.com',       'ACTIVE');
INSERT INTO students (student_id, full_name, email, status) VALUES (1005, 'Jean Claude Uwase',  'jc.uwase2@example.com',       'ACTIVE');  -- same name on purpose (TOO_MANY_ROWS demo)
INSERT INTO students (student_id, full_name, email, status) VALUES (1006, 'Patrick Niyonzima',  'patrick.n@example.com',       'SUSPENDED');
INSERT INTO students (student_id, full_name, email, status) VALUES (1007, 'Diane Ingabire',     'diane.ingabire@example.com',  'ACTIVE');
INSERT INTO students (student_id, full_name, email, status) VALUES (1008, 'Samuel Mugisha',     'samuel.mugisha@example.com',  'ACTIVE');

INSERT INTO courses (course_id, title, credits, capacity) VALUES ('INSY8311', 'Database Development with PL/SQL', 3, 5);
INSERT INTO courses (course_id, title, credits, capacity) VALUES ('STAT2201', 'Statistics',                       3, 40);
INSERT INTO courses (course_id, title, credits, capacity) VALUES ('MATH2101', 'Linear Algebra',                   4, 40);
INSERT INTO courses (course_id, title, credits, capacity) VALUES ('INSY8100', 'Advanced Database Seminar',        2, 2);   -- tiny capacity (course-full demo)

-- Semester 2026-S1 (graded)
INSERT INTO enrollments (student_id, course_id, semester, score) VALUES (1001, 'INSY8311', '2026-S1', 92);
INSERT INTO enrollments (student_id, course_id, semester, score) VALUES (1001, 'STAT2201', '2026-S1', 85);
INSERT INTO enrollments (student_id, course_id, semester, score) VALUES (1002, 'INSY8311', '2026-S1', 74);
INSERT INTO enrollments (student_id, course_id, semester, score) VALUES (1002, 'MATH2101', '2026-S1', 58);
INSERT INTO enrollments (student_id, course_id, semester, score) VALUES (1003, 'INSY8311', '2026-S1', 96);
INSERT INTO enrollments (student_id, course_id, semester, score) VALUES (1003, 'STAT2201', '2026-S1', 67);
INSERT INTO enrollments (student_id, course_id, semester, score) VALUES (1004, 'INSY8311', '2026-S1', 81);
INSERT INTO enrollments (student_id, course_id, semester, score) VALUES (1007, 'MATH2101', '2026-S1', 88);

-- Semester 2026-S2 (not graded yet)
INSERT INTO enrollments (student_id, course_id, semester) VALUES (1001, 'MATH2101', '2026-S2');
INSERT INTO enrollments (student_id, course_id, semester) VALUES (1008, 'INSY8311', '2026-S2');
INSERT INTO enrollments (student_id, course_id, semester) VALUES (1002, 'INSY8100', '2026-S2');
INSERT INTO enrollments (student_id, course_id, semester) VALUES (1003, 'INSY8100', '2026-S2');

COMMIT;
