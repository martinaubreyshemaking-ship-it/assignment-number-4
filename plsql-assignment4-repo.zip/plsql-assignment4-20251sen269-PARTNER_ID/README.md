# Group Assignment IV: Student Registration and Grading (Oracle PL/SQL)

**Course:** Database Development with PL/SQL (INSY 8311), AUCA
**Instructor:** Eric Maniraguha | **TA:** Afanyu Emmanuel

## Group members
| Name | Student ID |
|------|-----------|
| Aubrey Shema | 20251sen269 |
| Nzabarinda Ishimwe Armstrong| 29391 |

## Application description
A small university registration and grading system. Students enroll in courses per semester, lecturers record scores,
the letter grade is derived automatically, and every score change is audited.

**Requirements covered**
- Enroll a student (only ACTIVE students, only if seats remain, no duplicates).
- Update a score (0 to 100) with an audit trail; drop an enrollment only while it is ungraded.
- Print a transcript with GPA; compute GPA, course pass rate, seat counts, and look up a student by name.
- Bulk operations: enroll a whole cohort at once and curve all scores in a course, with per-row error reporting.

## Schema
`students`, `courses`, `enrollments` (UNIQUE student+course+semester, score CHECK 0..100, virtual `letter_grade`), `grade_audit`.
All relationships and constraints are in `00_schema/01_create_tables.sql`.

## Where each concept is used
| Concept | Where |
|---|---|
| %ROWTYPE records | `enroll_student`, `print_transcript`, `bulk_enroll_cohort`, `bulk_adjust_scores` |
| User-defined records | `print_transcript` (`t_transcript_rec`), `bulk_adjust_scores` (`t_audit_rec`) |
| Collections | Nested tables, associative array and VARRAY (`SYS.ODCINUMBERLIST`) in `bulk_adjust_scores`, `bulk_enroll_cohort`, `get_course_pass_rate` |
| Implicit cursors | `enroll_student` (INSERT), `update_score` (UPDATE), `drop_enrollment` (DELETE): `SQL%ROWCOUNT`, `SQL%FOUND`, `SQL%NOTFOUND` |
| Explicit cursor | `print_transcript` (parameterized, OPEN/FETCH/CLOSE, `%NOTFOUND`, `%ROWCOUNT`, `%ISOPEN`) |
| BULK COLLECT / FORALL | `bulk_adjust_scores`, `bulk_enroll_cohort`, `get_course_pass_rate` |
| Bulk DML errors | `FORALL ... SAVE EXCEPTIONS` + `SQL%BULK_EXCEPTIONS` in both bulk procedures |
| Predefined exceptions | `NO_DATA_FOUND`, `TOO_MANY_ROWS` (`get_student_id_by_name`), `DUP_VAL_ON_INDEX` |
| User-defined exceptions + RAISE_APPLICATION_ERROR | All procedures and functions (codes -20001 to -20090) |

## How to run
Run in SQL*Plus, SQL Developer or SQLcl, connected as the same schema user, in this order:
1. `00_schema/01_create_tables.sql`
2. `00_schema/02_insert_sample_data.sql`
3. **Functions first:** every file in `02_functions/` (the procedures call them, so they must compile first)
4. Every file in `01_procedures/`
5. `03_tests/test_success_cases.sql`, then `03_tests/test_error_cases.sql`
6. Check results against the `expect ...` comments and save screenshots in `screenshots/`

Requires Oracle 12c or later (identity columns, virtual columns).
Procedures do not COMMIT; the caller decides. The test scripts end with ROLLBACK so they can be re-run.

## Error codes
| Code | Meaning |
|---|---|
| -20001 / -20002 | Student / course not found (`enroll_student`) |
| -20003 | Student not ACTIVE |
| -20004 | Course full |
| -20005 | Already enrolled |
| -20010 / -20011 / -20012 | Invalid score / enrollment not found / nothing updated |
| -20021 | No ungraded enrollment to drop |
| -20030 | Student not found (`print_transcript`) |
| -20040 | Nothing graded (`bulk_adjust_scores`) |
| -20050 / -20051 / -20052 | Empty list / course not found / not enough seats (`bulk_enroll_cohort`) |
| -20060 / -20061 | Name not found / name ambiguous |
| -20070 / -20080 / -20090 | Course not found / student not found / nothing graded (functions) |

## Documentation
See `docs/IMPLEMENTATION_NOTES.md` for the implementation and performance explanation.

## AI usage disclosure
We used an AI assistant (Claude by Anthropic) to help generate the first draft of the schema, PL/SQL code, tests and documentation.
We reviewed, ran and tested the code ourselves, and both of us can explain it. (Edit this paragraph to describe exactly what you changed.)
