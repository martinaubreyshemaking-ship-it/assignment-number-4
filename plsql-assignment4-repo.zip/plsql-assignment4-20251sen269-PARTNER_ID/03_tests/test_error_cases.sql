-- test_error_cases.sql : every block should print "Caught: ORA-20xxx ..." (or bulk failure lines).
-- Run in a fresh session after the sample data (or after test_success_cases.sql, which rolls back).
SET SERVEROUTPUT ON SIZE UNLIMITED
SET LINESIZE 200

PROMPT === E1: enroll_student, unknown student (expect ORA-20001) ===
DECLARE v NUMBER; BEGIN enroll_student(9999, 'MATH2101', '2026-S2', v);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E2: enroll_student, unknown course (expect ORA-20002) ===
DECLARE v NUMBER; BEGIN enroll_student(1001, 'NOPE101', '2026-S2', v);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E3: enroll_student, suspended student (expect ORA-20003) ===
DECLARE v NUMBER; BEGIN enroll_student(1006, 'MATH2101', '2026-S2', v);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E4: enroll_student, course full (expect ORA-20004) ===
DECLARE v NUMBER; BEGIN enroll_student(1008, 'INSY8100', '2026-S2', v);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E5: enroll_student, duplicate / DUP_VAL_ON_INDEX (expect ORA-20005) ===
DECLARE v NUMBER; BEGIN enroll_student(1001, 'INSY8311', '2026-S1', v);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E6: update_score, invalid score (expect ORA-20010) ===
DECLARE o NUMBER; r PLS_INTEGER; BEGIN update_score(1, 150, o, r);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E7: update_score, enrollment does not exist / NO_DATA_FOUND (expect ORA-20011) ===
DECLARE o NUMBER; r PLS_INTEGER; BEGIN update_score(999999, 70, o, r);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E8: drop_enrollment on a graded record / SQL%NOTFOUND (expect ORA-20021) ===
DECLARE r PLS_INTEGER; BEGIN drop_enrollment(1001, 'INSY8311', '2026-S1', r);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E9: print_transcript, unknown student (expect ORA-20030) ===
BEGIN print_transcript(9999);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E10: get_student_id_by_name, not found (expect ORA-20060) ===
DECLARE v NUMBER; BEGIN v := get_student_id_by_name('Nobody Here');
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E11: get_student_id_by_name, TOO_MANY_ROWS (expect ORA-20061) ===
DECLARE v NUMBER; BEGIN v := get_student_id_by_name('Jean Claude Uwase');
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E12: calculate_student_gpa, unknown student (expect ORA-20080) ===
DECLARE v NUMBER; BEGIN v := calculate_student_gpa(9999);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E13: get_course_pass_rate, nothing graded (expect ORA-20090) ===
DECLARE v NUMBER; BEGIN v := get_course_pass_rate('INSY8100', '2026-S2');
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E14: get_course_enrollment_count, unknown course (expect ORA-20070) ===
DECLARE v NUMBER; BEGIN v := get_course_enrollment_count('NOPE101', '2026-S1');
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E15: bulk_enroll_cohort with bad rows (SAVE EXCEPTIONS: expect 2 enrolled, 2 failed) ===
DECLARE ok PLS_INTEGER; bad PLS_INTEGER;
BEGIN
  -- 9999 = unknown student (FK ORA-02291), 1001 = already enrolled (ORA-00001)
  bulk_enroll_cohort('STAT2201', '2026-S1', SYS.ODCINUMBERLIST(1004, 9999, 1001, 1005), ok, bad);
  DBMS_OUTPUT.PUT_LINE('Result: enrolled=' || ok || ', failed=' || bad);
END;
/

PROMPT === E16: bulk_enroll_cohort, not enough seats (expect ORA-20052) ===
DECLARE ok PLS_INTEGER; bad PLS_INTEGER;
BEGIN bulk_enroll_cohort('INSY8311', '2026-S1', SYS.ODCINUMBERLIST(1005, 1007, 1008), ok, bad);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E17: bulk_enroll_cohort, empty list (expect ORA-20050) ===
DECLARE ok PLS_INTEGER; bad PLS_INTEGER;
BEGIN bulk_enroll_cohort('STAT2201', '2026-S1', SYS.ODCINUMBERLIST(), ok, bad);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

PROMPT === E18: bulk_adjust_scores +5, one score would exceed 100 (expect 3 updated, 1 failed: ORA-02290) ===
DECLARE ok PLS_INTEGER; bad PLS_INTEGER;
BEGIN
  bulk_adjust_scores('INSY8311', '2026-S1', 5, ok, bad);   -- 96 + 5 = 101 violates chk_enr_score
  DBMS_OUTPUT.PUT_LINE('Result: updated=' || ok || ', failed=' || bad);
END;
/
SELECT student_id, score, letter_grade FROM enrollments WHERE course_id = 'INSY8311' AND semester = '2026-S1' ORDER BY student_id;
SELECT COUNT(*) AS audit_rows_written FROM grade_audit;   -- expect 3 (failed row not audited)

PROMPT === E19: bulk_adjust_scores, nothing graded (expect ORA-20040) ===
DECLARE ok PLS_INTEGER; bad PLS_INTEGER;
BEGIN bulk_adjust_scores('INSY8100', '2026-S2', 5, ok, bad);
EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Caught: ' || SQLERRM); END;
/

ROLLBACK;
