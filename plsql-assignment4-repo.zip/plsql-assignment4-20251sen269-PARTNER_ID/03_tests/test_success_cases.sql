-- test_success_cases.sql : run AFTER schema, sample data, functions and procedures.
-- Take one screenshot per test (see screenshots/ naming in README). Ends with ROLLBACK so it can be re-run.
SET SERVEROUTPUT ON SIZE UNLIMITED
SET LINESIZE 200

PROMPT === S1: enroll_student (implicit INSERT, %ROWTYPE, OUT param) ===
DECLARE
  v_id enrollments.enrollment_id%TYPE;
BEGIN
  enroll_student(1008, 'MATH2101', '2026-S2', v_id);
  DBMS_OUTPUT.PUT_LINE('New enrollment id: ' || v_id);
END;
/

PROMPT === S2: update_score (implicit UPDATE, SQL%ROWCOUNT / SQL%FOUND) ===
DECLARE
  v_enr  enrollments.enrollment_id%TYPE;
  v_old  enrollments.score%TYPE;
  v_rows PLS_INTEGER;
BEGIN
  SELECT enrollment_id INTO v_enr
    FROM enrollments
   WHERE student_id = 1002 AND course_id = 'INSY8311' AND semester = '2026-S1';
  update_score(v_enr, 80, v_old, v_rows);
  DBMS_OUTPUT.PUT_LINE('Old score: ' || v_old || ', rows updated: ' || v_rows);   -- expect 74, 1
END;
/
SELECT enrollment_id, old_score, new_score, changed_by FROM grade_audit;

PROMPT === S3: drop_enrollment (implicit DELETE, SQL%ROWCOUNT) ===
DECLARE
  v_rows PLS_INTEGER;
BEGIN
  drop_enrollment(1008, 'MATH2101', '2026-S2', v_rows);   -- drops the row created in S1
  DBMS_OUTPUT.PUT_LINE('Rows deleted: ' || v_rows);        -- expect 1
END;
/

PROMPT === S4: print_transcript (explicit cursor, user-defined record) ===
BEGIN
  print_transcript(1001);   -- expect GPA 3.5
END;
/

PROMPT === S5: functions called from SQL ===
SELECT calculate_student_gpa(1001)                      AS gpa_1001,         -- expect 3.5
       get_course_pass_rate('INSY8311', '2026-S1')      AS pass_rate_pct,    -- expect 100
       get_course_enrollment_count('INSY8311', '2026-S1') AS enrolled,       -- expect 4
       get_student_id_by_name('Aline Uwimana')          AS id_aline          -- expect 1001
  FROM dual;

PROMPT === S6: functions called from an anonymous block ===
DECLARE
  v_gpa  NUMBER;
  v_rate NUMBER;
BEGIN
  v_gpa  := calculate_student_gpa(1002);
  v_rate := get_course_pass_rate('STAT2201', '2026-S1');
  DBMS_OUTPUT.PUT_LINE('GPA 1002 = ' || v_gpa || ' | STAT2201 pass rate = ' || v_rate || '%');
END;
/

PROMPT === S7: bulk_enroll_cohort (VARRAY + FORALL, all succeed) ===
DECLARE
  v_ok PLS_INTEGER; v_bad PLS_INTEGER;
BEGIN
  bulk_enroll_cohort('STAT2201', '2026-S1', SYS.ODCINUMBERLIST(1004, 1007, 1008), v_ok, v_bad);  -- expect 3 / 0
END;
/

PROMPT === S8: bulk_adjust_scores (BULK COLLECT + FORALL, all succeed) ===
DECLARE
  v_ok PLS_INTEGER; v_bad PLS_INTEGER;
BEGIN
  bulk_adjust_scores('INSY8311', '2026-S1', 3, v_ok, v_bad);   -- expect 4 / 0
END;
/
SELECT student_id, score, letter_grade FROM enrollments WHERE course_id = 'INSY8311' AND semester = '2026-S1' ORDER BY student_id;

ROLLBACK;
