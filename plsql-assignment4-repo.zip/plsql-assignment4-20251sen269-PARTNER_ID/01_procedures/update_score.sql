-- Updates one enrollment's score and writes an audit row.
-- Concepts: implicit cursor (UPDATE) with SQL%ROWCOUNT / SQL%FOUND, OUT parameters,
--           NO_DATA_FOUND, user-defined exception, RAISE_APPLICATION_ERROR.
-- The caller controls COMMIT/ROLLBACK.
CREATE OR REPLACE PROCEDURE update_score (
  p_enrollment_id IN  enrollments.enrollment_id%TYPE,
  p_new_score     IN  enrollments.score%TYPE,
  p_old_score     OUT enrollments.score%TYPE,
  p_rows_updated  OUT PLS_INTEGER
)
IS
  e_invalid_score EXCEPTION;
BEGIN
  IF p_new_score IS NULL OR p_new_score < 0 OR p_new_score > 100 THEN
    RAISE e_invalid_score;
  END IF;

  -- lock the row and capture the old score (NO_DATA_FOUND if the enrollment does not exist)
  SELECT score INTO p_old_score
    FROM enrollments
   WHERE enrollment_id = p_enrollment_id
     FOR UPDATE;

  UPDATE enrollments
     SET score = p_new_score
   WHERE enrollment_id = p_enrollment_id;

  p_rows_updated := SQL%ROWCOUNT;   -- read the attribute immediately, before the next DML

  IF SQL%FOUND THEN
    INSERT INTO grade_audit (enrollment_id, old_score, new_score)
    VALUES (p_enrollment_id, p_old_score, p_new_score);
    DBMS_OUTPUT.PUT_LINE('Score updated (' || p_rows_updated || ' row). ' ||
                         NVL(TO_CHAR(p_old_score), 'NULL') || ' -> ' || p_new_score);
  ELSE
    RAISE_APPLICATION_ERROR(-20012, 'Update touched no rows for enrollment ' || p_enrollment_id || '.');
  END IF;
EXCEPTION
  WHEN e_invalid_score THEN
    RAISE_APPLICATION_ERROR(-20010, 'Score must be between 0 and 100 (got ' || NVL(TO_CHAR(p_new_score), 'NULL') || ').');
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20011, 'Enrollment ' || p_enrollment_id || ' does not exist.');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Unexpected error in update_score: ' || SQLERRM);
    RAISE;
END update_score;
/
SHOW ERRORS
