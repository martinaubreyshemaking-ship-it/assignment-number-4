-- Enrolls one student in a course for a semester.
-- Concepts: %ROWTYPE records, implicit cursor (INSERT + SQL%ROWCOUNT), OUT parameter,
--           NO_DATA_FOUND, DUP_VAL_ON_INDEX, user-defined exceptions, RAISE_APPLICATION_ERROR.
CREATE OR REPLACE PROCEDURE enroll_student (
  p_student_id    IN  students.student_id%TYPE,
  p_course_id     IN  courses.course_id%TYPE,
  p_semester      IN  enrollments.semester%TYPE,
  p_enrollment_id OUT enrollments.enrollment_id%TYPE
)
IS
  l_student students%ROWTYPE;   -- %ROWTYPE record
  l_course  courses%ROWTYPE;    -- %ROWTYPE record
  l_step    VARCHAR2(10);

  e_student_inactive EXCEPTION; -- user-defined
  e_course_full      EXCEPTION; -- user-defined
BEGIN
  l_step := 'STUDENT';
  SELECT * INTO l_student FROM students WHERE student_id = p_student_id;

  IF l_student.status <> 'ACTIVE' THEN
    RAISE e_student_inactive;
  END IF;

  l_step := 'COURSE';
  SELECT * INTO l_course FROM courses WHERE course_id = p_course_id;

  IF get_course_enrollment_count(p_course_id, p_semester) >= l_course.capacity THEN
    RAISE e_course_full;
  END IF;

  INSERT INTO enrollments (student_id, course_id, semester)
  VALUES (p_student_id, p_course_id, p_semester)
  RETURNING enrollment_id INTO p_enrollment_id;

  DBMS_OUTPUT.PUT_LINE('Enrolled ' || l_student.full_name || ' in ' || l_course.title ||
                       ' (' || p_semester || '). Rows inserted: ' || SQL%ROWCOUNT);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    IF l_step = 'STUDENT' THEN
      RAISE_APPLICATION_ERROR(-20001, 'Student ' || p_student_id || ' does not exist.');
    ELSE
      RAISE_APPLICATION_ERROR(-20002, 'Course ' || p_course_id || ' does not exist.');
    END IF;
  WHEN e_student_inactive THEN
    RAISE_APPLICATION_ERROR(-20003, 'Student ' || p_student_id || ' is ' || l_student.status || ' and cannot enroll.');
  WHEN e_course_full THEN
    RAISE_APPLICATION_ERROR(-20004, 'Course ' || p_course_id || ' is full for ' || p_semester || ' (capacity ' || l_course.capacity || ').');
  WHEN DUP_VAL_ON_INDEX THEN
    RAISE_APPLICATION_ERROR(-20005, 'Student ' || p_student_id || ' is already enrolled in ' || p_course_id || ' for ' || p_semester || '.');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Unexpected error in enroll_student: ' || SQLERRM);
    RAISE;  -- never swallow unexpected errors
END enroll_student;
/
SHOW ERRORS
