-- Drops an UNGRADED enrollment.
-- Concepts: implicit cursor (DELETE) with SQL%ROWCOUNT and SQL%NOTFOUND, OUT parameter.
CREATE OR REPLACE PROCEDURE drop_enrollment (
  p_student_id   IN  enrollments.student_id%TYPE,
  p_course_id    IN  enrollments.course_id%TYPE,
  p_semester     IN  enrollments.semester%TYPE,
  p_rows_deleted OUT PLS_INTEGER
)
IS
BEGIN
  DELETE FROM enrollments
   WHERE student_id = p_student_id
     AND course_id  = p_course_id
     AND semester   = p_semester
     AND score IS NULL;               -- graded records must be kept

  p_rows_deleted := SQL%ROWCOUNT;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(-20021,
      'No ungraded enrollment found for student ' || p_student_id || ' in ' || p_course_id ||
      ' (' || p_semester || '). It may not exist or may already be graded.');
  END IF;

  DBMS_OUTPUT.PUT_LINE('Dropped enrollment. Rows deleted: ' || p_rows_deleted);
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE = -20021 THEN
      RAISE;                           -- our own meaningful error, pass it on unchanged
    END IF;
    DBMS_OUTPUT.PUT_LINE('Unexpected error in drop_enrollment: ' || SQLERRM);
    RAISE;
END drop_enrollment;
/
SHOW ERRORS
