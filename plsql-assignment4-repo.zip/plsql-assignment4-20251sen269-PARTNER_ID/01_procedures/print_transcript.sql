-- Prints a student's transcript.
-- Concepts: user-defined record, %ROWTYPE, parameterized EXPLICIT cursor (OPEN / FETCH / CLOSE),
--           cursor attributes %NOTFOUND, %ROWCOUNT, %ISOPEN, NO_DATA_FOUND.
CREATE OR REPLACE PROCEDURE print_transcript (
  p_student_id IN students.student_id%TYPE
)
IS
  TYPE t_transcript_rec IS RECORD (            -- user-defined record
    course_id    courses.course_id%TYPE,
    title        courses.title%TYPE,
    credits      courses.credits%TYPE,
    semester     enrollments.semester%TYPE,
    score        enrollments.score%TYPE,
    letter_grade enrollments.letter_grade%TYPE
  );
  l_row     t_transcript_rec;
  l_student students%ROWTYPE;                  -- %ROWTYPE record
  l_gpa     NUMBER;

  CURSOR c_transcript (cp_student_id NUMBER) IS
    SELECT c.course_id, c.title, c.credits, e.semester, e.score, e.letter_grade
      FROM enrollments e
      JOIN courses c ON c.course_id = e.course_id
     WHERE e.student_id = cp_student_id
     ORDER BY e.semester, c.course_id;
BEGIN
  SELECT * INTO l_student FROM students WHERE student_id = p_student_id;

  DBMS_OUTPUT.PUT_LINE('TRANSCRIPT: ' || l_student.full_name || ' (ID ' || l_student.student_id || ', ' || l_student.status || ')');
  DBMS_OUTPUT.PUT_LINE(RPAD('-', 70, '-'));

  OPEN c_transcript(p_student_id);
  LOOP
    FETCH c_transcript INTO l_row;
    EXIT WHEN c_transcript%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(
      RPAD(l_row.semester, 9) || RPAD(l_row.course_id, 10) || RPAD(l_row.title, 36) ||
      LPAD(l_row.credits || 'cr', 5) || LPAD(NVL(TO_CHAR(l_row.score), '-'), 7) ||
      LPAD(NVL(l_row.letter_grade, '-'), 3));
  END LOOP;
  DBMS_OUTPUT.PUT_LINE(RPAD('-', 70, '-'));
  DBMS_OUTPUT.PUT_LINE('Courses listed: ' || c_transcript%ROWCOUNT);
  CLOSE c_transcript;

  l_gpa := calculate_student_gpa(p_student_id);
  DBMS_OUTPUT.PUT_LINE('GPA: ' || NVL(TO_CHAR(l_gpa, 'FM0.00'), 'N/A (no graded courses)'));
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20030, 'Student ' || p_student_id || ' does not exist.');
  WHEN OTHERS THEN
    IF c_transcript%ISOPEN THEN
      CLOSE c_transcript;
    END IF;
    DBMS_OUTPUT.PUT_LINE('Unexpected error in print_transcript: ' || SQLERRM);
    RAISE;
END print_transcript;
/
SHOW ERRORS
