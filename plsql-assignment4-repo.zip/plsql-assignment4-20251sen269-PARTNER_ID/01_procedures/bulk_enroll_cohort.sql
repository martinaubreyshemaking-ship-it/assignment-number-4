-- Enrolls many students in one course with a single FORALL INSERT.
-- Concepts: VARRAY parameter (SYS.ODCINUMBERLIST), FORALL ... SAVE EXCEPTIONS,
--           SQL%BULK_EXCEPTIONS, %ROWTYPE record, NO_DATA_FOUND, user-defined exception.
-- Rows that fail (unknown student, duplicate) are reported; the valid rows are still inserted.
-- The caller controls COMMIT/ROLLBACK.
CREATE OR REPLACE PROCEDURE bulk_enroll_cohort (
  p_course_id   IN  courses.course_id%TYPE,
  p_semester    IN  enrollments.semester%TYPE,
  p_student_ids IN  SYS.ODCINUMBERLIST,
  p_enrolled    OUT PLS_INTEGER,
  p_failed      OUT PLS_INTEGER
)
IS
  l_course  courses%ROWTYPE;
  l_current NUMBER;

  e_course_full  EXCEPTION;
  e_bulk_errors  EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_bulk_errors, -24381);   -- raised by FORALL ... SAVE EXCEPTIONS
BEGIN
  p_enrolled := 0;
  p_failed   := 0;

  IF p_student_ids IS NULL OR p_student_ids.COUNT = 0 THEN
    RAISE_APPLICATION_ERROR(-20050, 'The list of student IDs is empty.');
  END IF;

  SELECT * INTO l_course FROM courses WHERE course_id = p_course_id;

  l_current := get_course_enrollment_count(p_course_id, p_semester);
  IF l_current + p_student_ids.COUNT > l_course.capacity THEN
    RAISE e_course_full;
  END IF;

  BEGIN
    FORALL i IN 1 .. p_student_ids.COUNT SAVE EXCEPTIONS
      INSERT INTO enrollments (student_id, course_id, semester)
      VALUES (p_student_ids(i), p_course_id, p_semester);
  EXCEPTION
    WHEN e_bulk_errors THEN
      p_failed := SQL%BULK_EXCEPTIONS.COUNT;
      FOR j IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
        DBMS_OUTPUT.PUT_LINE('  FAILED student ' ||
          p_student_ids(SQL%BULK_EXCEPTIONS(j).ERROR_INDEX) || ': ' ||
          SQLERRM(-SQL%BULK_EXCEPTIONS(j).ERROR_CODE));
      END LOOP;
  END;

  p_enrolled := p_student_ids.COUNT - p_failed;
  DBMS_OUTPUT.PUT_LINE('Bulk enroll in ' || p_course_id || ': ' || p_enrolled || ' enrolled, ' || p_failed || ' failed.');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20051, 'Course ' || p_course_id || ' does not exist.');
  WHEN e_course_full THEN
    RAISE_APPLICATION_ERROR(-20052, 'Not enough seats in ' || p_course_id || ' for ' || p_semester ||
      ': ' || l_current || ' taken + ' || p_student_ids.COUNT || ' requested > capacity ' || l_course.capacity || '.');
  WHEN OTHERS THEN
    IF SQLCODE BETWEEN -20999 AND -20000 THEN
      RAISE;
    END IF;
    DBMS_OUTPUT.PUT_LINE('Unexpected error in bulk_enroll_cohort: ' || SQLERRM);
    RAISE;
END bulk_enroll_cohort;
/
SHOW ERRORS
