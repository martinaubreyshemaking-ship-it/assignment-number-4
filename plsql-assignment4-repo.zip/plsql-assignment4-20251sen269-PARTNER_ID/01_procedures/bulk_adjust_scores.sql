-- Adds p_points to every graded score in a course/semester (curve or correction).
-- Concepts: BULK COLLECT into a nested table of %ROWTYPE, associative array, user-defined record
--           collection, FORALL UPDATE ... SAVE EXCEPTIONS, FORALL INSERT (audit),
--           SQL%BULK_EXCEPTIONS, user-defined error codes.
-- A score pushed outside 0..100 violates chk_enr_score; that row fails, the rest succeed,
-- and only the successful rows are audited.
-- The caller controls COMMIT/ROLLBACK.
CREATE OR REPLACE PROCEDURE bulk_adjust_scores (
  p_course_id IN  courses.course_id%TYPE,
  p_semester  IN  enrollments.semester%TYPE,
  p_points    IN  NUMBER,
  p_updated   OUT PLS_INTEGER,
  p_failed    OUT PLS_INTEGER
)
IS
  TYPE t_enr_tab    IS TABLE OF enrollments%ROWTYPE;                 -- nested table of records
  TYPE t_score_tab  IS TABLE OF enrollments.score%TYPE;              -- nested table
  TYPE t_failed_map IS TABLE OF BOOLEAN INDEX BY PLS_INTEGER;        -- associative array
  TYPE t_audit_rec  IS RECORD (                                      -- user-defined record
    enrollment_id enrollments.enrollment_id%TYPE,
    old_score     enrollments.score%TYPE,
    new_score     enrollments.score%TYPE
  );
  TYPE t_audit_tab  IS TABLE OF t_audit_rec;

  l_enrollments t_enr_tab;
  l_new_scores  t_score_tab := t_score_tab();
  l_failed      t_failed_map;
  l_audit       t_audit_tab := t_audit_tab();

  e_bulk_errors EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_bulk_errors, -24381);
BEGIN
  p_updated := 0;
  p_failed  := 0;

  -- 1) one round trip to read all rows (BULK COLLECT)
  SELECT *
    BULK COLLECT INTO l_enrollments
    FROM enrollments
   WHERE course_id = p_course_id
     AND semester  = p_semester
     AND score IS NOT NULL
     FOR UPDATE;

  IF l_enrollments.COUNT = 0 THEN
    RAISE_APPLICATION_ERROR(-20040, 'No graded enrollments for ' || p_course_id || ' in ' || p_semester || '.');
  END IF;

  -- 2) compute new scores in memory
  l_new_scores.EXTEND(l_enrollments.COUNT);
  FOR i IN 1 .. l_enrollments.COUNT LOOP
    l_new_scores(i) := l_enrollments(i).score + p_points;
  END LOOP;

  -- 3) one bulk UPDATE; failures are collected instead of aborting everything
  BEGIN
    FORALL i IN 1 .. l_enrollments.COUNT SAVE EXCEPTIONS
      UPDATE enrollments
         SET score = l_new_scores(i)
       WHERE enrollment_id = l_enrollments(i).enrollment_id;
  EXCEPTION
    WHEN e_bulk_errors THEN
      FOR j IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
        l_failed(SQL%BULK_EXCEPTIONS(j).ERROR_INDEX) := TRUE;
        DBMS_OUTPUT.PUT_LINE('  FAILED enrollment ' ||
          l_enrollments(SQL%BULK_EXCEPTIONS(j).ERROR_INDEX).enrollment_id || ' (' ||
          l_enrollments(SQL%BULK_EXCEPTIONS(j).ERROR_INDEX).score || ' + ' || p_points || '): ' ||
          SQLERRM(-SQL%BULK_EXCEPTIONS(j).ERROR_CODE));
      END LOOP;
  END;

  -- 4) audit only the rows that really changed
  FOR i IN 1 .. l_enrollments.COUNT LOOP
    IF NOT l_failed.EXISTS(i) THEN
      l_audit.EXTEND;
      l_audit(l_audit.LAST).enrollment_id := l_enrollments(i).enrollment_id;
      l_audit(l_audit.LAST).old_score     := l_enrollments(i).score;
      l_audit(l_audit.LAST).new_score     := l_new_scores(i);
    END IF;
  END LOOP;

  IF l_audit.COUNT > 0 THEN
    FORALL i IN 1 .. l_audit.COUNT
      INSERT INTO grade_audit (enrollment_id, old_score, new_score)
      VALUES (l_audit(i).enrollment_id, l_audit(i).old_score, l_audit(i).new_score);
  END IF;

  p_failed  := l_failed.COUNT;
  p_updated := l_enrollments.COUNT - p_failed;
  DBMS_OUTPUT.PUT_LINE('Bulk adjust ' || p_points || ' pts in ' || p_course_id || ' ' || p_semester ||
                       ': ' || p_updated || ' updated, ' || p_failed || ' failed.');
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE BETWEEN -20999 AND -20000 THEN
      RAISE;
    END IF;
    DBMS_OUTPUT.PUT_LINE('Unexpected error in bulk_adjust_scores: ' || SQLERRM);
    RAISE;
END bulk_adjust_scores;
/
SHOW ERRORS
